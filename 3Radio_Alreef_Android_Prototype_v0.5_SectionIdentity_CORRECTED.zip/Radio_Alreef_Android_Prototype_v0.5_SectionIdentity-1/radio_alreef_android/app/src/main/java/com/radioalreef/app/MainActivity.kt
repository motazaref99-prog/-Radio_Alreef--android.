package com.radioalreef.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF355C49)
private val DeepForest = Color(0xFF244436)
private val Sand = Color(0xFFF3EFE5)
private val WarmWhite = Color(0xFFFFFEFA)
private val Gray = Color(0xFF777D78)
private val Ink = Color(0xFF202923)
private val Accent = Color(0xFFC79A55)
private val NewsTone = Color(0xFF3F6F8F)
private val AudioTone = Color(0xFFB17A36)
private val ProgramsTone = Color(0xFF6C7650)
private val CommunityTone = Color(0xFF8B675B)
private val SoftBlue = Color(0xFFE8F0F4)
private val SoftGold = Color(0xFFF5EBDD)
private val SoftGreen = Color(0xFFEBF0E7)
private val SoftRose = Color(0xFFF3EAE6)

private val AlreefKufi = FontFamily(
    Font(R.font.alreef_kufi_regular, FontWeight.Normal),
    Font(R.font.alreef_kufi_medium, FontWeight.Medium),
    Font(R.font.alreef_kufi_bold, FontWeight.Bold),
    Font(R.font.alreef_kufi_black, FontWeight.Black)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RadioAlreefApp() }
    }
}

@Composable
fun RadioAlreefApp() {
    var selected by remember { mutableStateOf("الرئيسية") }
    var saved by remember { mutableStateOf(setOf<Int>()) }
    val stories = listOf(
        Story(1, "المحويت", "مشاهد من الحياة الزراعية في مدرجات المحويت", "تقرير ميداني • 4 دقائق", "الزراعة والريف"),
        Story(2, "البيئة والمناخ", "كيف تؤثر التغيرات المناخية في المجتمعات الريفية؟", "ملف خاص • 6 دقائق", "البيئة"),
        Story(3, "المجتمع", "مبادرات أهلية تعيد الحياة إلى الطرق الريفية", "قصة مجتمع • 3 دقائق", "تنمية محلية")
    )
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Forest, secondary = Accent, background = Sand, surface = WarmWhite
    )) {
        Scaffold(
            containerColor = Sand,
            bottomBar = {
                NavigationBar(containerColor = WarmWhite) {
                    val tabs = listOf(
                        "الرئيسية" to Icons.Default.Home,
                        "الأخبار" to Icons.Default.Article,
                        "استمع" to Icons.Default.Radio,
                        "البرامج" to Icons.Default.Podcasts,
                        "المزيد" to Icons.Default.Menu
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "استمع" -> AudioLibraryScreen(Modifier.padding(padding))
                "الأخبار" -> NewsScreen(stories, saved, { id ->
                    saved = if (id in saved) saved - id else saved + id
                }, Modifier.padding(padding))
                "البرامج" -> ProgramsScreen(Modifier.padding(padding))
                "المزيد" -> MoreScreen(Modifier.padding(padding))
                else -> HomeScreen(stories, saved, { selected = "استمع" }, { selected = "الأخبار" }, Modifier.padding(padding))
            }
        }
    }
}

data class Story(val id: Int, val section: String, val title: String, val meta: String, val category: String)

@Composable
fun SectionHeading(
    title: String,
    subtitle: String,
    tone: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(46.dp).background(tone.copy(alpha = 0.12f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = tone, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun BrandHeader() {
    Row(
        Modifier.fillMaxWidth().background(Forest).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(116.dp).height(76.dp).background(WarmWhite, RoundedCornerShape(12.dp)).padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.alreef_logo),
                contentDescription = "شعار راديو الريف",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("راديو الريف", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.4).sp)
            Text("صوت المجتمع.. نبض الريف", color = Color.White.copy(alpha = .9f), fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.15.sp)
        }
    }
}

@Composable
fun HomeScreen(stories: List<Story>, saved: Set<Int>, onListen: () -> Unit, onNews: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        BrandHeader()
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text("مرحباً بك في راديو الريف", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("منصتك لمتابعة أخبار وقضايا المجتمع والريف اليمني", color = Gray, fontSize = 13.sp)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = DeepForest), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Radio, null, tint = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Text("المكتبة الصوتية", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Surface(color = Accent, shape = CircleShape) {
                                Text("قريباً", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = DeepForest, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("استمع إلى الحلقات والبرامج والتقارير الصوتية المنشورة في مكتبة راديو الريف.", color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = onListen, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepForest)) {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text("المكتبة الصوتية")
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("أحدث الأخبار", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onNews) { Text("عرض الكل") }
                }
            }
            items(stories) { story -> StoryCard(story, story.id in saved) { } }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = WarmWhite), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Campaign, null, tint = Forest, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("شاركنا خبراً من مجتمعك", color = Ink, fontWeight = FontWeight.Bold)
                            Text("نرحب بمشاركات المواطنين ومراسلي الريف", color = Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewsScreen(stories: List<Story>, saved: Set<Int>, onSave: (Int) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        BrandHeader()
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SectionHeading("الأخبار والتقارير", "آخر المستجدات من المجتمع والريف", NewsTone, Icons.Default.Article) }
            items(stories) { story ->
                Column {
                    StoryCard(story, story.id in saved) { onSave(story.id) }
                    TextButton(onClick = { onSave(story.id) }) {
                        Icon(if (story.id in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null)
                        Spacer(Modifier.width(5.dp))
                        Text(if (story.id in saved) "إزالة من المحفوظات" else "حفظ الخبر")
                    }
                }
            }
        }
    }
}

@Composable
fun StoryCard(story: Story, isSaved: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = when(story.category) {
                    "البيئة" -> SoftGreen
                    "تنمية محلية" -> SoftRose
                    else -> SoftBlue
                }, shape = RoundedCornerShape(20.dp)) {
                    Text(story.section, Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = when(story.category) {
                        "البيئة" -> ProgramsTone
                        "تنمية محلية" -> CommunityTone
                        else -> NewsTone
                    }, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.weight(1f))
                if (isSaved) Icon(Icons.Default.Bookmark, null, tint = Accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(story.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(story.meta, color = Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun AudioLibraryScreen(modifier: Modifier = Modifier) {
    val tracks = listOf(
        Triple("زوايا أسرية", "حرمان المرأة من الميراث", "12:35"),
        Triple("فرسان الريف", "حكايات من قرى المحويت", "08:42"),
        Triple("البيئة والمناخ", "التين الشوكي والحشرة القرمزية", "06:18"),
        Triple("صوت المواطن", "مبادرات أهلية لخدمة الطرق", "04:56")
    )
    var selectedTrack by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize()) {
        BrandHeader()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeading("المكتبة الصوتية", "حلقات وبرامج وتقارير مسموعة", AudioTone, Icons.Default.Headphones)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = DeepForest), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Headphones, null, tint = Color.White, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("الملف المحدد", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                                Text(tracks[selectedTrack].second, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Accent, trackColor = Color.White.copy(alpha = .2f))
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { selectedTrack = (selectedTrack - 1 + tracks.size) % tracks.size; isPlaying = false }) {
                                Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                            }
                            IconButton(onClick = { isPlaying = !isPlaying }, modifier = Modifier.size(54.dp).background(Color.White, CircleShape)) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = DeepForest, modifier = Modifier.size(32.dp))
                            }
                            IconButton(onClick = { selectedTrack = (selectedTrack + 1) % tracks.size; isPlaying = false }) {
                                Icon(Icons.Default.SkipNext, null, tint = Color.White)
                            }
                        }
                        Text("واجهة المشغل جاهزة؛ يلزم إضافة ملفات صوتية فعلية لتفعيل التشغيل.", color = Color.White.copy(alpha = .75f), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item { Text("الملفات الصوتية", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            items(tracks.size) { index ->
                val track = tracks[index]
                Card(
                    colors = CardDefaults.cardColors(containerColor = WarmWhite),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().clickable { selectedTrack = index; isPlaying = false }
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(Sand, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AudioFile, null, tint = Forest)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.second, color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${track.first} • ${track.third}", color = Gray, fontSize = 10.sp)
                        }
                        IconButton(onClick = { selectedTrack = index; isPlaying = false }) {
                            Icon(Icons.Default.PlayCircle, null, tint = Forest, modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProgramsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        BrandHeader()
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeading("برامج راديو الريف", "مساحات تحكي الناس والأرض والحياة", ProgramsTone, Icons.Default.Podcasts)
            listOf(
                Triple("زوايا أسرية", "قضايا الأسرة والمرأة والمجتمع", CommunityTone),
                Triple("فرسان الريف", "حكايات ومواهب من الأرياف", Accent),
                Triple("البيئة والمناخ", "تقارير عن الأرض والمياه والتغير المناخي", ProgramsTone),
                Triple("صوت المواطن", "مساحة لقضايا الناس ومبادراتهم", NewsTone)
            ).forEachIndexed { index, item ->
                val (name, desc, tone) = item
                Card(colors = CardDefaults.cardColors(containerColor = WarmWhite), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(tone.copy(alpha = .13f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Icon(
                                when(index) {
                                    0 -> Icons.Default.FamilyRestroom
                                    1 -> Icons.Default.Terrain
                                    2 -> Icons.Default.Eco
                                    else -> Icons.Default.RecordVoiceOver
                                },
                                null, tint = tone, modifier = Modifier.size(27.dp)
                            )
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(desc, color = Gray, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronLeft, null, tint = tone)
                    }
                }
            }
        }
    }
}

@Composable
fun MoreScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        BrandHeader()
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            SectionHeading("عن راديو الريف", "صوت المجتمع.. نبض الريف", Forest, Icons.Default.Info)
            Text("منصة إعلامية مجتمعية تهتم بقضايا الريف اليمني، وتنقل صوت المجتمعات المحلية وقصصها واحتياجاتها.", color = Gray, fontSize = 14.sp)
            HorizontalDivider()
            Text("أرسل خبراً", color = Ink, fontWeight = FontWeight.Bold)
            Text("يمكن إضافة نموذج استقبال الأخبار ومرفقات الصور والفيديو في المرحلة التالية.", color = Gray, fontSize = 12.sp)
            HorizontalDivider()
            Text("الإعدادات • سياسة الخصوصية • تواصل معنا", color = Forest, fontSize = 13.sp)
            Text("الإصدار التجريبي 0.1.0", color = Gray, fontSize = 11.sp)
        }
    }
}
